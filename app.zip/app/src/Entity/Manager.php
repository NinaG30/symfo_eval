<?php

namespace App\Entity;

use App\Repository\ManagerRepository;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: ManagerRepository::class)]
class Manager
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\Column(length: 100)]
    private ?string $nom = null;

    #[ORM\Column(length: 100)]
    private ?string $role = null;

    #[ORM\Column]
    private ?int $salaire = null;

    #[ORM\ManyToOne(inversedBy: 'managers')]
    private ?Team $equipe = null;
   

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getNom(): ?string
    {
        return $this->nom;
    }

    public function setNom(string $nom): self
    {
        $this->nom = $nom;

        return $this;
    }

    public function getRole(): ?string
    {
        return $this->role;
    }

    public function setRole(string $role): self
    {
        $this->role = $role;

        return $this;
    }

    public function getSalaire(): ?int
    {
        return $this->salaire;
    }

    public function setSalaire(int $salaire): self
    {
        $this->salaire = $salaire;

        return $this;
    }

    public function getEquipe(): ?Team
    {
        return $this->equipe;
    }

    public function setEquipe(?Team $equipe): self
    {
        $this->equipe = $equipe;

        return $this;
    }

    public function countRole(){
        $count = 0;
        if ($this->getRole() === 'Directeur Sportif'){
            $count ++;
        }

        return $count;
    }
}
