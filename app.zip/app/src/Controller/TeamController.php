<?php

namespace App\Controller;

use App\Form\EquipeType;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\Request;
use Doctrine\ORM\EntityManagerInterface;
use Doctrine\Persistence\ManagerRegistry;
use App\Entity\Joueur;
use App\Entity\Team;

class TeamController extends AbstractController
{
    #[Route('/creer', name: 'app_creer')]
    public function create(EntityManagerInterface $entityManager, Request $request): Response
    {
         

        $team = new Team();
        $form = $this->createForm(EquipeType::class, $team);
        $form->handleRequest($request);

        $joueur = $entityManager
        ->getRepository(Joueur::class)
        ->OrderJoueur();

        if ($form->isSubmitted() && $form->isValid()) 
        {
            $data = $form->getData(); 

            $session = $request->getSession();                       
            $session->set('Equipe', $data);
           
            return $this->render('team/index.html.twig', [
                'message1' => 'Ok!',
                'message' => 'Créer une équipe',
                'joueurs' => $joueur,
                'form' => $form->createView()    
            ]);
        }


        return $this->render('team/index.html.twig', [
            'message' => 'Créer une équipe',
            'joueurs' => $joueur,
            'form' => $form->createView()         
        ]);
    }

    #[Route('/selectionner', name: 'app_selectionner')]
    public function select(ManagerRegistry $doctrine): Response
    {
        $team = $doctrine
        ->getRepository(Team::class)
        ->findAll();
        
        return $this->render('team/select.html.twig', [
            'message' => 'Selectionner une équipe',
            'teams' => $team
        ]);
    }
}
