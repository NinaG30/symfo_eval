<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class HistoController extends AbstractController
{
    #[Route('/historique', name: 'app_histo')]
    public function histo(): Response
    {
        return $this->render('histo/index.html.twig', [
            'message' => 'Historique compétition',
        ]);
    }
}
