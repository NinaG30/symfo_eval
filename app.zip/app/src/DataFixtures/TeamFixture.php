<?php

namespace App\DataFixtures;

use Doctrine\Bundle\FixturesBundle\Fixture;
use Doctrine\Persistence\ObjectManager;
use App\Entity\Team;
use App\Entity\Manager;
use App\Entity\Joueur;
use Faker\Factory;

class TeamFixture extends Fixture
{
    public function load(ObjectManager $manager): void
    {
        //! bloc moche!!!!!!
        
        //ramène 1 directeurSportif  
        $directeurSportif = $manager
            ->getRepository(Manager::class)
            ->findManagerByRole('Directeur Sportif');

        $directeurMedia = $manager
            ->getRepository(Manager::class)
            ->findManagerByRole('Directeur Media');

        $directeurG = $manager
            ->getRepository(Manager::class)
            ->findManagerByRole('Directeur Général');

        $entraineur = $manager
            ->getRepository(Manager::class)
            ->findManagerByRole('Entraineur principal');

        $suppleant = $manager
            ->getRepository(Manager::class)
            ->findManagerByRole('Suppléant');


        //J'ajoute à ma team mes managers //!moche!!!!!!
        $team = $this->getTeam();
        $team->addManager($directeurSportif);
        $team->setBudget($directeurSportif->getSalaire());
        $directeurSportif->setEquipe($team);
        $team->addManager($directeurMedia);
        $team->setBudget($directeurMedia->getSalaire());
        $directeurMedia->setEquipe($team);
        $team->addManager($directeurG);
        $team->setBudget($directeurG->getSalaire());
        $directeurG->setEquipe($team);
        $team->addManager($entraineur);
        $team->setBudget($entraineur->getSalaire());
        $entraineur->setEquipe($team);
        $team->addManager($suppleant);
        $team->setBudget($suppleant->getSalaire());
        $suppleant->setEquipe($team);


        //J'obtiens mon goal
        $goal = $manager
            ->getRepository(Joueur::class)
            ->findGoal();

        //j'ajoute mon goal
        $team->addJoueur($goal);

        //j'obties mes autres joueurs
        $joueurs = $manager
            ->getRepository(Joueur::class)
            ->findJoueurs();

        // J'ajoute chaque joueur à ma team
        foreach ($joueurs as $joueur) {
            $team->addJoueur($joueur);
            $joueur->setEquipe($team);
            $team->setRating($joueur->getRating());
            $team->setBudget($joueur->getSalaire());
        }

        //Le rating de ma team suivant les joueurs
        $teamRating = $team->getRating() / count($joueurs) + 1;
        $team->finalRating($teamRating);

        //Le budget de ma team suivant les joueurs/managers;
        $teambudget = $team->getBudget();


       //envoie dans la base
       $manager->persist($team);
       $manager->flush();
    }


    public function getTeam()
    {

        $faker = Factory::create('fr_FR');

        $nom = $faker->name();
        $ville = $faker->city();
        $team = new Team();
        $team->setNom($nom);
        $team->setVille($ville);

        return $team;
    }
}