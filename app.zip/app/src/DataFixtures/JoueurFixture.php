<?php

namespace App\DataFixtures;

use App\Entity\Joueur;
use Doctrine\Bundle\FixturesBundle\Fixture;
use Doctrine\Persistence\ObjectManager;
use Faker\Factory;

class JoueurFixture extends Fixture
{
    public function load(ObjectManager $manager): void
    {

        // $this->addJoueur($manager);
        // $manager->flush();
    }

    public function addJoueur(ObjectManager $manager)
    {
        for ($i = 0; $i < 200; $i++) {
            $manager->persist($this->getJoueur());
        }
    }

    public function getJoueur()
    {
        $faker = Factory::create('fr_FR');

        //Générer un nom/prenom aléatoire
        $nom = $faker->name($gender='male');

        //Générer une position aléatoire
        $positions = ['Avant', 'Milieu', 'Arrière', 'Goal'];
        $position = $positions[random_int(0, 3)];

        //Générer vitesse aléatoire
        $vitesse = $faker->numberBetween(0, 100);

        //Générer dribble aléatoire
        $dribble = $faker->numberBetween(0, 100);

        //Générer tir aléatoire
        $tir = $faker->numberBetween(0, 100);

        //Générer rating aléatoire
        $rating = $faker->numberBetween(0, 100);

        //Générer arret aléatoire
        $arret = $faker->numberBetween(0, 100);

        //Générer salaire aléatoire
        $salaire = $faker->randomNumber(5, true);

        $joueur = new Joueur();
        $joueur->setNom($nom);
        $joueur->setPosition($position);
        $pos = $joueur->getPosition();
        if ($pos === 'Goal') {$joueur->setArret($arret);}
        $joueur->setVitesse($vitesse);
        $joueur->setDribble($dribble);
        $joueur->setTir($tir);
        $joueur->setRating($rating);
        $joueur->setSalaire($salaire);

        return $joueur;
    }
}