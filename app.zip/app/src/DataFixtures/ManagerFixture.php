<?php

namespace App\DataFixtures;

use App\Entity\Manager;
use Doctrine\Bundle\FixturesBundle\Fixture;
use Doctrine\Persistence\ObjectManager;
use Faker\Factory;

class ManagerFixture extends Fixture
{
  

    public function load(ObjectManager $manager): void
    {
        // $this->addManager($manager);
        // $manager->flush();
    }

    public function addManager(ObjectManager $manager)
    {
        for ($i = 0; $i < 30; $i++) {
            $manager->persist($this->getManager());
        }
    }

    public function getManager()
    {   
        $faker = Factory::create('fr_FR');
        
        // Générer un nom/prenom aléatoire      
        $nom = $faker->name();
        
        // Générer un rôle aléatoire
        $roles = ['Directeur Général', 'Directeur Sportif', 'Directeur Media', 'Entraineur principal', 'Suppléant'];
        $role = $roles[random_int(0, 4)];

        //Générer un salaire aléatoire
        $salaire = $faker->randomNumber(6, true);

        //Instanciation d'un l'objet de la classe Manager
        $manager = new Manager();
        $manager->setNom($nom);
        $manager->setRole($role);
        $manager->setSalaire($salaire);

        // On renvoie le résultat
        return $manager;
    }
}